// ============================================================
//  Pi Game V1 — TFT_eSPI_User_Setup.h
//
//  KURULUM TALIMATI:
//  Bu dosyanin icerigini asagidaki konumdaki User_Setup.h ile
//  DEGISTIR (uzerine yaz):
//
//    Windows:
//      C:\Users\<KullaniciAdi>\Documents\Arduino\libraries\TFT_eSPI\User_Setup.h
//
//  Degistirdikten sonra Arduino IDE'yi yeniden baslat.
// ============================================================

// ============================================================
// SURUCU SECIMI
// ============================================================
#define ILI9341_DRIVER          // 2.8" ILI9341 TFT LCD

// Ekran cozunurlugu
#define TFT_WIDTH   240
#define TFT_HEIGHT  320

// ============================================================
// RP2040 SPI0 PIN TANIM LARI
// (Earle Philhower Arduino Core ile uyumlu)
// ============================================================
#define TFT_MOSI    19          // GP19 — SPI0 TX
#define TFT_SCLK    18          // GP18 — SPI0 SCK
#define TFT_CS      17          // GP17 — Chip Select
#define TFT_DC      20          // GP20 — Data / Command
#define TFT_RST     21          // GP21 — Reset
// Not: TFT_MISO ekrana veri okumak icin kullanilmaz,
//      sadece SPI0 tanimlanmasi gerekirse GP16 eklenebilir.

// ============================================================
// SPI FREKANS
// ============================================================
#define SPI_FREQUENCY        75000000   // 75 MHz (ILI9341 overclock)
#define SPI_READ_FREQUENCY   20000000   // Okuma icin daha dusuk

// ============================================================
// FONT YUKLEMELERI
// ============================================================
#define LOAD_GLCD       // Font 1 — ASCII (her zaman dahil edilmeli)
#define LOAD_FONT2      // Font 2 — kuculuk boyut
#define LOAD_FONT4      // Font 4 — orta boyut
#define LOAD_FONT6      // Font 6 — buyuk sayisal
#define LOAD_FONT7      // Font 7 — 7-segment gorunum
#define LOAD_FONT8      // Font 8 — en buyuk
#define LOAD_GFXFF      // FreeFONT destegi

// Smooth font (SPIFFS/SD ile)
#define SMOOTH_FONT
