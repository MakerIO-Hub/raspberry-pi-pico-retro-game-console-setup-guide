// ============================================================
//  Pi Game V1 — pin_config.h
//  Sabit Pin Haritasi (Sadece A ve B Butonlari)
// ============================================================
#pragma once

// ------------------------------------------------------------
// EKRAN — ILI9341 TFT 2.8"  (SPI0)
// ------------------------------------------------------------
#define PIN_TFT_CS    17   // GP17
#define PIN_TFT_DC    20   // GP20
#define PIN_TFT_RST   21   // GP21
#define PIN_TFT_MOSI  19   // GP19
#define PIN_TFT_SCK   18   // GP18
#define PIN_TFT_LED   22   // GP22 (PWM)

// ------------------------------------------------------------
// SD KART — Ekran PCB arkasindan entegre  (SPI1)
// ------------------------------------------------------------
#define PIN_SD_SCK    10   // GP10
#define PIN_SD_MOSI   11   // GP11
#define PIN_SD_MISO   12   // GP12
#define PIN_SD_CS     13   // GP13

// ------------------------------------------------------------
// SES — MAX98357A I2S Dijital Amfi
// ------------------------------------------------------------
#define PIN_I2S_BCLK  26   // GP26
#define PIN_I2S_WS    27   // GP27 (otomatik atanan pin)
#define PIN_I2S_DIN   28   // GP28

// ------------------------------------------------------------
// BUTONLAR — 10k Pull-Up (INPUT_PULLUP)
// ------------------------------------------------------------
#define PIN_BTN_LEFT    0
#define PIN_BTN_RIGHT   1
#define PIN_BTN_UP      2
#define PIN_BTN_DOWN    3
#define PIN_BTN_START   4
#define PIN_BTN_SELECT  5
#define PIN_BTN_A       6
#define PIN_BTN_B       7

// Buton indexleri (Dizi icin)
#define BTN_LEFT    0
#define BTN_RIGHT   1
#define BTN_UP      2
#define BTN_DOWN    3
#define BTN_START   4
#define BTN_SELECT  5
#define BTN_A       6
#define BTN_B       7
#define BTN_COUNT   8
