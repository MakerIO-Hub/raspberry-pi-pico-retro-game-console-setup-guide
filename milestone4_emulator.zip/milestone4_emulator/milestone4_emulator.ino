#pragma GCC optimize("O3")
#pragma GCC optimize("inline")
#pragma GCC optimize("omit-frame-pointer")

// ============================================================
//  Pi Game V1 — Pico 2 (RP2350) Kararlı ve Nihai Sürüm calısan kod
//  Milestone 4 — Çift Çekirdek Render, DMA ve Tam Ekran Ölçekleme
//
//  Amaç: ROM dosyasını tek seferde Pico 2'nin harici QSPI Flash 
//  belleğine yazarken Core 1'i RAM'e kilitleyerek donanımsal 
//  kilitlenmeyi bütünüyle önlemek ve oyunları 60 FPS çalıştırmak.
//  Otomatik SRAM Save/Load (.sav) ve donanımsal hızlı çıkış aktif.
// ============================================================

#include <SPI.h>
#include <TFT_eSPI.h>
#include <SdFat.h>
#include "pin_config.h"

// Pico 2 Donanımsal Flash Bellek, Önbellek ve Watchdog Sürücüleri
#include "hardware/flash.h"
#include "hardware/sync.h"
#include "hardware/watchdog.h" 
#include "hardware/gpio.h" 

// ============================================================
// DONANIMSAL QSPI FLASH BELLEK HARİTALAMA AYARLARI
// ============================================================
// Pico 2 program kodunun üzerine yazmamak için ROM'u 256 KB (262144 byte) ofsetine yazıyoruz
#define FLASH_ROM_OFFSET (256 * 1024)

// XIP (Execute In Place) adresi üzerinden doğrudan Flash hafıza okuma göstericisi
const uint8_t *rom_ptr = (const uint8_t *)(XIP_BASE + FLASH_ROM_OFFSET);

// ============================================================
// FONKSİYON PROTOTİPLERİ (FORWARD DECLARATIONS - DERLEME HATASI ÇÖZÜMÜ)
// ============================================================
void getSavePath(const char* romName, char* savePath, size_t maxLen);
void loadSRAM(const char* romName);
void saveSRAM(const char* romName);
void startEmulator();
void stopEmulator();
void scanRoms();
void drawMenu();
void drawHeader(const char* title);
void showError(const char* errorMsg);

// ============================================================
// WALNUT-CGB YAPILANDIRMASI (header'dan ÖNCE tanımlanmalı)
// ============================================================
#define ENABLE_LCD 1
#define WALNUT_GB_12_COLOUR 1
#define WALNUT_FULL_GBC_SUPPORT 1
#define WALNUT_GB_RGB565_BIGENDIAN 0

// Walnut-CGB ses register okuma/yazma için stub fonksiyonlar
uint8_t audio_read(uint16_t addr) {
  (void)addr;
  return 0xFF;
}

void audio_write(uint16_t addr, uint8_t val) {
  (void)addr;
  (void)val;
}

// Walnut-CGB tek-header emülatör kütüphanesi
#include "walnut_cgb.h"

// ============================================================
// NESNE TANIMLARI
// ============================================================
TFT_eSPI  tft = TFT_eSPI();
SdFat     sd;

// ============================================================
// RENK PALETİ (RGB565)
// ============================================================
#define C_BG        0x0820
#define C_PANEL     0x1082
#define C_TITLE     0xFDA0
#define C_TEXT      0xFFFF
#define C_ACCENT    0x03E0
#define C_GRAY      0x8410

File32 romFile;
uint32_t romFileSize = 0;

// ============================================================
// ÇİFT ÇEKİRDEK GÜVENLİK VE EKRAN SAHİPLİĞİ KİLİDİ
// ============================================================
volatile bool tftOwnedByCore1 = false; 

// ============================================================
// CART RAM (Save dosyası) — Şimdilik RAM'de tutuluyor
// ============================================================
#define CART_RAM_SIZE 32768  // 32KB
uint8_t cartRam[CART_RAM_SIZE];

// ============================================================
// EMÜLATÖR NESNESİ
// ============================================================
struct gb_s gb;

// ============================================================
// RENK DOĞRULUĞU & DÜZELTME (DMG Modu İçin)
// ============================================================
#define SCREEN_COLOR_BGR 0 

inline uint16_t pack_color(uint8_t r, uint8_t g, uint8_t b) {
  // GBC Renk Düzeltme Filtresi (Gerçek GBC LCD ekranının renk matrisi)
  uint8_t cr = (r * 27 + g * 5) >> 5;
  uint8_t cg = (g * 22 + b * 10) >> 5;
  uint8_t cb = (r * 4 + g * 4 + b * 24) >> 5;

  // 5-bit Green'den 6-bit'e hassas genişletme
  uint8_t cg6 = (cg << 1) | (cg >> 4);

  uint16_t packed;
#if SCREEN_COLOR_BGR
  packed = (cb << 11) | (cg6 << 5) | cr; // BGR Modu
#else
  packed = (cr << 11) | (cg6 << 5) | cb; // RGB Modu
#endif

  // Big-Endian byte swap (TFT SPI DMA için zorunlu)
  return (packed >> 8) | (packed << 8);
}

uint16_t dmgPalette[4];

void initDmgPalette() {
  dmgPalette[0] = pack_color(28, 31, 24); 
  dmgPalette[1] = pack_color(18, 24, 14); 
  dmgPalette[2] = pack_color(8,  14, 8);  
  dmgPalette[3] = pack_color(1,  3,  1);  
}

// ============================================================
// ÇİFT TAMPON YAPISI (DOUBLE BUFFER) & PAYLAŞIMLI PALET
// ============================================================
#define GBC_WIDTH  160
#define GBC_HEIGHT 144
#define OUT_WIDTH  320
#define OUT_HEIGHT 240

uint8_t frameBuffer[2][GBC_WIDTH * GBC_HEIGHT];
volatile uint8_t writeBufferIdx = 0;
volatile uint8_t readBufferIdx = 1;

// Çift tamponlu paylaşımlı palet dizisi (Sadece 256 byte kaplar ve işlemciyi yormaz)
uint16_t sharedPalette[2][64];

// Hız kazanmak için dinamik kare atlama (Frame Skip) ve Core 1 durum kontrolü
volatile bool skipNextFrame = false;
volatile bool core1Busy = false;

// === CORE 1 DUAL-CORE FLASH KORUMA KİLİDİ ===
volatile bool core1Paused = false;

// Sadece RAM üzerinde koşan ve Flash erişimini tamamen kesen kilit fonksiyonu [1]
void __attribute__((section(".time_critical"))) core1_wait_in_ram() {
  while (core1Paused) {
    __asm volatile("nop"); // İşlemciyi RAM üzerinde meşgul et, Flash okumasını sıfırla [1]
  }
  // === CORE 1 RESMİ CACHE FLUSH (SİYAH EKRAN ÇÖZÜMÜ - RP2350 UYUMLU) ===
  flash_flush_cache(); 
}

// ============================================================
// ÖLÇEKLENME LOOKUP TABLOLARI & DMA TAMPONLARI
// ============================================================
uint16_t srcY[OUT_HEIGHT]; 
uint8_t gbcLineMap[OUT_HEIGHT]; // Bölme işlemini sıfırlayan hızlı satır haritası

#define DMA_BLOCK_LINES 8
uint16_t dmaBlockBuffer[2][OUT_WIDTH * DMA_BLOCK_LINES];

// ============================================================
// MENU VERİLERİ (GELİŞTİRİLDİ)
// ============================================================
#define MAX_ROMS 256
char romList[MAX_ROMS][64]; 
int romCount = 0;
int selectedIndex = 0;
int scrollOffset = 0;
const int VISIBLE_ITEMS = 7;

const int BTN_PINS[BTN_COUNT] = { PIN_BTN_LEFT, PIN_BTN_RIGHT, PIN_BTN_UP,
                                  PIN_BTN_DOWN, PIN_BTN_START, PIN_BTN_SELECT,
                                  PIN_BTN_A,    PIN_BTN_B };

bool sdOK = false;
volatile bool emuRunning = false;

unsigned long lastFpsTime = 0;
int frameCount = 0;
int currentFps = 0;

// ============================================================
// ÖLÇEKLENME LOOKUP TABLOSU İLKLENDİRME (GELİŞTİRİLDİ)
// ============================================================
void initScalingTables() {
  for (int y = 0; y < OUT_HEIGHT; y++) {
    srcY[y] = ((y * GBC_HEIGHT) / OUT_HEIGHT) * GBC_WIDTH;
    gbcLineMap[y] = (y * GBC_HEIGHT) / OUT_HEIGHT;
  }
}

// ============================================================
// WALNUT-CGB CALLBACK FONKSIYONLARI (Core 0 - RAM Üzerinden Akacaktır)
// ============================================================

uint8_t __attribute__((section(".time_critical"))) gb_rom_read_cb(struct gb_s *gb, const uint_fast32_t addr) {
  return rom_ptr[addr];
}

uint16_t __attribute__((section(".time_critical"))) gb_rom_read16_cb(struct gb_s *gb, const uint_fast32_t addr) {
  return *(uint16_t*)&rom_ptr[addr];
}

uint32_t __attribute__((section(".time_critical"))) gb_rom_read32_cb(struct gb_s *gb, const uint_fast32_t addr) {
  return *(uint32_t*)&rom_ptr[addr];
}

uint8_t gb_cart_ram_read_cb(struct gb_s *gb, const uint_fast32_t addr) {
  if (addr < CART_RAM_SIZE) return cartRam[addr];
  return 0xFF;
}

void gb_cart_ram_write_cb(struct gb_s *gb, const uint_fast32_t addr, const uint8_t val) {
  if (addr < CART_RAM_SIZE) cartRam[addr] = val;
}

void gb_error_cb(struct gb_s *gb, const int err, const uint16_t addr) {
  Serial.print("[EMU HATA] Kod: ");
  Serial.print(err);
  Serial.print("  Adres: 0x");
  Serial.println(addr, HEX);
}

// --- LCD Satır Çizme Callback (Core 0) ---
void __not_in_flash_func(lcd_draw_line_cb)(struct gb_s *gb, const uint8_t *pixels, const uint_fast8_t line) {
  uint8_t *dest = &frameBuffer[writeBufferIdx][line * GBC_WIDTH];
  memcpy(dest, pixels, GBC_WIDTH);

  if (line == (GBC_HEIGHT - 1)) {
    if (core1Busy || skipNextFrame) {
      skipNextFrame = false; 
      return; 
    }

    // --- GBC RENK DÜZELTME & AKTARIM ---
    if (gb->cgb.cgbMode) {
      for (int i = 0; i < 64; i++) {
        uint16_t color = gb->cgb.fixPalette[i];
        uint8_t r = (color >> 11) & 0x1F;
        uint8_t g = (color >> 6) & 0x1F; // 6-bit Green'den 5-bit'e düşür
        uint8_t b = color & 0x1F;
        sharedPalette[writeBufferIdx][i] = pack_color(r, g, b);
      }
    }

    readBufferIdx = writeBufferIdx;
    writeBufferIdx = 1 - writeBufferIdx;
    
    // --- DONANIMSAL KUSURSUZ FIFO PAYLOAD ---
    rp2040.fifo.push_nb(readBufferIdx);
  }
}

// ============================================================
// CORE 0 SETUP & LOOP
// ============================================================
void setup() {
  Serial.begin(115200);

  // === DONANIMSAL KİLİT KIRICI: GÜÇLÜ RESET PALSİ ===
  pinMode(PIN_TFT_RST, OUTPUT);
  digitalWrite(PIN_TFT_RST, LOW);  
  delay(50);                       
  digitalWrite(PIN_TFT_RST, HIGH); 
  delay(50);                       

  // === DONANIMSAL SD KART RESET PROTOKOLÜ (DUMMY CLOCKS) ===
  pinMode(PIN_SD_CS, OUTPUT);
  digitalWrite(PIN_SD_CS, HIGH); 
  pinMode(PIN_SD_SCK, OUTPUT);
  for (int i = 0; i < 80; i++) {
    digitalWrite(PIN_SD_SCK, LOW);
    delayMicroseconds(10);
    digitalWrite(PIN_SD_SCK, HIGH);
    delayMicroseconds(10);
  }
  delay(50); 

  tftOwnedByCore1 = false;

  pinMode(PIN_TFT_LED, OUTPUT);
  analogWrite(PIN_TFT_LED, 204);

  for (int i = 0; i < BTN_COUNT; i++) {
    pinMode(BTN_PINS[i], INPUT_PULLUP);
  }

  tft.init();
  tft.setRotation(3); 
  tft.fillScreen(C_BG);
  tft.initDMA();

  // === HIGH-SPEED SPI SİNYAL GÜRBÜZLEŞTİRME OPTİMİZASYONU ===
  gpio_set_drive_strength(PIN_TFT_SCK, GPIO_DRIVE_STRENGTH_12MA);
  gpio_set_drive_strength(PIN_TFT_MOSI, GPIO_DRIVE_STRENGTH_12MA);

  initDmgPalette();
  initScalingTables();

  drawHeader("Pi Game V1 Yukleniyor...");

  Serial.println("SD Kart baslatiliyor...");
  SPI1.setRX(PIN_SD_MISO);
  SPI1.setTX(PIN_SD_MOSI);
  SPI1.setSCK(PIN_SD_SCK);
  SPI1.begin();

  if (sd.begin(SdSpiConfig(PIN_SD_CS, DEDICATED_SPI, SD_SCK_MHZ(12), &SPI1))) {
    sdOK = true;
    scanRoms();
  } else {
    sdOK = false;
    showError("SD Kart Hatasi!");
  }

  if (sdOK) {
    Serial.print("Bulunan oyun sayisi: ");
    Serial.println(romCount);
    drawMenu();
  }
}

void loop() {
  if (emuRunning) {
    emuLoop();
  } else {
    menuLoop();
  }
}

// ============================================================
// CORE 1 SETUP & LOOP (Çift Çekirdek Çizim Motoru)
// ============================================================
void setup1() {
  // Boş bırakılmıştır.
}

void loop1() {
  // --- CORE 1 GÜVENLİK KİLİDİ ---
  if (core1Paused) {
    core1_wait_in_ram();
    return;
  }

  if (!emuRunning || !tftOwnedByCore1) {
    delay(10); 
    return;
  }

  if (rp2040.fifo.available() == 0) {
    delay(1); 
    return;
  }

  // --- DONANIMSAL FIFO OKUMA ---
  uint8_t currentReadIdx = rp2040.fifo.pop();

  core1Busy = true; 

  tft.startWrite();
  tft.setAddrWindow(0, 0, OUT_WIDTH, OUT_HEIGHT);

  for (int block = 0; block < OUT_HEIGHT / DMA_BLOCK_LINES; block++) {
    uint8_t dmaIdx = block % 2;
    uint16_t *dest = dmaBlockBuffer[dmaIdx];

    tft.dmaWait();

    for (int line = 0; line < DMA_BLOCK_LINES; line++) {
      int y = block * DMA_BLOCK_LINES + line;
      uint8_t *srcLine = &frameBuffer[currentReadIdx][srcY[y]];
      
      uint16_t gbcLine = gbcLineMap[y];

      if (gb.cgb.cgbMode) {
        for (int x = 0; x < GBC_WIDTH; x++) {
          uint16_t finalColor = sharedPalette[currentReadIdx][srcLine[x] & 0x3F];
          *dest++ = finalColor;
          *dest++ = finalColor;
        }
      } else {
        for (int x = 0; x < GBC_WIDTH; x++) {
          uint16_t finalColor = dmgPalette[srcLine[x] & 0x03];
          *dest++ = finalColor;
          *dest++ = finalColor;
        }
      }
    }

    tft.pushPixelsDMA(dmaBlockBuffer[dmaIdx], OUT_WIDTH * DMA_BLOCK_LINES);
  }

  tft.dmaWait();
  tft.endWrite();

  // Çizim tamamen bitti, kilidi kaldır
  core1Busy = false;
}

// ============================================================
// CORE 0 MENU DÖNGÜSÜ
// ============================================================
void menuLoop() {
  if (!sdOK) return;

  if (digitalRead(PIN_BTN_UP) == LOW) {
    if (romCount > 0 && selectedIndex > 0) {
      selectedIndex--;
      if (selectedIndex < scrollOffset) scrollOffset = selectedIndex;
      drawMenu();
    }
    delay(200);
  }

  if (digitalRead(PIN_BTN_DOWN) == LOW) {
    if (romCount > 0 && selectedIndex < romCount - 1) {
      selectedIndex++;
      if (selectedIndex >= scrollOffset + VISIBLE_ITEMS)
        scrollOffset = selectedIndex - VISIBLE_ITEMS + 1;
      drawMenu();
    }
    delay(200);
  }

  if (digitalRead(PIN_BTN_A) == LOW) {
    if (romCount > 0) {
      startEmulator();
    }
    delay(200);
  }

  delay(10);
}

// ============================================================
// OTOMATİK SRAM SAVE/LOAD (.sav) ALTYAPISI (YENİ SÜRÜM)
// ============================================================
// ROM ismini alıp uzantısını .sav olarak değiştirerek dosya yolunu üretir
void getSavePath(const char* romName, char* savePath, size_t maxLen) {
  snprintf(savePath, maxLen, "/SAVES/%s", romName);
  char *dot = strrchr(savePath, '.');
  if (dot) {
    strcpy(dot, ".sav"); // Doğrudan orijinal .sav formatı
  } else {
    strcat(savePath, ".sav");
  }
}

// Oyun başlarken SD karttan .sav dosyasını RAM'e yükler (Auto-Load on Boot)
void loadSRAM(const char* romName) {
  char savePath[128];
  getSavePath(romName, savePath, sizeof(savePath));
  
  File32 saveFile;
  if (saveFile.open(savePath, O_RDONLY)) {
    saveFile.read(cartRam, CART_RAM_SIZE);
    saveFile.close();
    Serial.print("Kartus kayit dosyasi (.sav) yuklendi: ");
    Serial.println(savePath);
  } else {
    memset(cartRam, 0xFF, CART_RAM_SIZE); // Kayıt yoksa RAM'i temizle
    Serial.println("Kayit bulunamadi, temiz hafiza baslatiliyor.");
  }
}

// RAM'deki güncel ilerlemeyi SD karttaki .sav dosyasına yazar (Auto-Save on Exit)
void saveSRAM(const char* romName) {
  char savePath[128];
  getSavePath(romName, savePath, sizeof(savePath));
  
  if (!sd.exists("/SAVES/")) {
    sd.mkdir("/SAVES/");
  }
  
  File32 saveFile;
  if (saveFile.open(savePath, O_WRONLY | O_CREAT | O_TRUNC)) {
    saveFile.write(cartRam, CART_RAM_SIZE);
    saveFile.close();
    Serial.print("Oyun otomatik kaydedildi: ");
    Serial.println(savePath);
  } else {
    Serial.println("Hata: Otomatik kayit yazilamadi!");
  }
}

// ============================================================
// CORE 0 EMÜLATÖR DÖNGÜSÜ
// ============================================================
void emuLoop() {
  unsigned long frameStartUs = micros();

  gb.direct.joypad_bits.up     = digitalRead(PIN_BTN_UP);
  gb.direct.joypad_bits.down   = digitalRead(PIN_BTN_DOWN);
  gb.direct.joypad_bits.left   = digitalRead(PIN_BTN_LEFT);
  gb.direct.joypad_bits.right  = digitalRead(PIN_BTN_RIGHT);
  gb.direct.joypad_bits.a      = digitalRead(PIN_BTN_A);
  gb.direct.joypad_bits.b      = digitalRead(PIN_BTN_B);
  gb.direct.joypad_bits.start  = digitalRead(PIN_BTN_START);
  gb.direct.joypad_bits.select = digitalRead(PIN_BTN_SELECT);

  gb_run_frame_dualfetch(&gb);

  frameCount++;
  unsigned long now = millis();
  if (now - lastFpsTime >= 1000) {
    currentFps = frameCount;
    frameCount = 0;
    lastFpsTime = now;
    Serial.print("FPS: ");
    Serial.println(currentFps);
  }

  // === %100 OTOMATİK VE DONANIMSEL RESETLİ GEÇİŞ ===
  // Kombinasyona basıldığı an oyun arka planda otomatik kaydedilir ve sistem anında sıfırlanır!
  if (digitalRead(PIN_BTN_SELECT) == LOW && digitalRead(PIN_BTN_START) == LOW) {
    delay(300); // Kısa bekleme
    if (digitalRead(PIN_BTN_SELECT) == LOW && digitalRead(PIN_BTN_START) == LOW) {
      emuRunning = false;
      while (core1Busy) { delay(1); } // Çekirdeği bekle
      
      tft.fillScreen(C_BG);
      tft.fillRect(0, 80, 320, 80, C_PANEL);
      tft.drawFastHLine(0, 80, 320, C_ACCENT);
      tft.drawFastHLine(0, 160, 320, C_ACCENT);
      tft.setTextColor(C_TITLE, C_PANEL);
      tft.setTextDatum(MC_DATUM);
      tft.drawString("Oyun Kaydediliyor...", 160, 105, 2);
      tft.setTextColor(C_TEXT, C_PANEL);
      tft.drawString("Menuye Donuluyor...", 160, 135, 2);
      tft.dmaWait();

      // Orijinal .sav kaydını SD karta sessizce yap
      saveSRAM(romList[selectedIndex]);
      
      // Donanımsal temiz kapatma
      romFile.close();
      sd.card()->writeStop();
      delay(100); // SD kartın uykuya girmesi için güvenli süre

      // Pico 2'yi donanımsal olarak anında sıfırla! [1]
      watchdog_reboot(0, 0, 0); 
    }
  }

  // --- ADAPTİF KARE ATLAMA ---
  unsigned long elapsedUs = micros() - frameStartUs;
  if (elapsedUs > 16743) {
    skipNextFrame = true; 
  } else {
    delayMicroseconds(16743 - elapsedUs);
  }
}

// ============================================================
// EMÜLATÖRÜ BAŞLAT (Core 0 - RAM'e Önceden Yükleme Mantığı)
// ============================================================
void startEmulator() {
  tft.fillScreen(C_BG);
  tft.fillRect(0, 80, 320, 80, C_PANEL);
  tft.drawFastHLine(0, 80, 320, C_TITLE);
  tft.drawFastHLine(0, 160, 320, C_TITLE);
  tft.setTextColor(C_TITLE, C_PANEL);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("ROM Yukleniyor...", 160, 105, 2);
  tft.setTextColor(C_TEXT, C_PANEL);
  tft.drawString(romList[selectedIndex], 160, 135, 2);

  tft.dmaWait();

  char romPath[128];
  snprintf(romPath, sizeof(romPath), "/ROMS/%s", romList[selectedIndex]);

  Serial.print("ROM aciliyor: ");
  Serial.println(romPath);

  if (!romFile.open(romPath, O_RDONLY)) {
    showError("ROM acilamadi!");
    delay(2000);
    drawMenu();
    return;
  }

  romFileSize = romFile.fileSize();
  Serial.print("ROM boyutu: ");
  Serial.print(romFileSize);
  Serial.println(" byte");

  // === CORE 1 GÜVENLİK KİLİDİNİ ÇALIŞTIR ===
  // Core 1'i RAM üzerindeki NOP döngüsüne alarak Flash ile olan tüm elektriksel bağını kes! [1]
  core1Paused = true;
  delay(50); // Çekirdeğin RAM döngüsüne girmesi için güvenli geçiş süresi ver

  // === PICO 2 DOĞAL QSPI FLASH PROGRAMLAMA ENGINE ===
  Serial.println("Boş QSPI Flash alanı siliniyor...");
  uint32_t erase_size = (romFileSize + 4095) & ~4095; // 4KB Sektör hizalaması
  
  uint32_t ints = save_and_disable_interrupts(); // Yazma sırasında Core 0 kesmelerini de kapat [2]
  flash_range_erase(FLASH_ROM_OFFSET, erase_size);
  restore_interrupts(ints);

  Serial.println("ROM, QSPI Flash belleğe kopyalanıyor (Preload)...");
  uint8_t pageBuffer[4096] __attribute__((aligned(4)));
  uint32_t bytesWritten = 0;

  while (bytesWritten < romFileSize) {
    uint32_t toRead = 4096;
    if (bytesWritten + toRead > romFileSize) toRead = romFileSize - bytesWritten;

    memset(pageBuffer, 0xFF, 4096);
    romFile.read(pageBuffer, toRead);

    uint32_t writeInts = save_and_disable_interrupts();
    flash_range_program(FLASH_ROM_OFFSET + bytesWritten, pageBuffer, 4096); // 256-Byte hizalı donanımsal yazma
    restore_interrupts(writeInts);

    bytesWritten += 4096;
  }
  Serial.println("QSPI Flash kopyalama tamamlandı! SD kart devredışı bırakıldı.");
  
  romFile.close(); // === KOPYALAMA BİTER BİTMEZ DOSYAYI KAPAT, SD KART KİLİDİNİ AÇ! ===

  // === CORE 1'İ RAM KİLİDİNDEN KURTAR VE SERBEST BIRAK ===
  core1Paused = false;

  // === SRAM KAYDI OTOMATİK YÜKLE (YENİ SÜRÜM) ===
  // Oyunun orijinal .sav dosyasını otomatik olarak SRAM'e yükler (Sıfır Tuş Basımı!)
  loadSRAM(romList[selectedIndex]);

  while (rp2040.fifo.available() > 0) {
    rp2040.fifo.pop();
  }

  enum gb_init_error_e ret = gb_init(
    &gb,
    gb_rom_read_cb,
    gb_rom_read16_cb,
    gb_rom_read32_cb,
    gb_cart_ram_read_cb,
    gb_cart_ram_write_cb,
    (void (*)(struct gb_s*, const enum gb_error_e, const uint16_t))gb_error_cb,
    NULL
  );

  if (ret != GB_INIT_NO_ERROR) {
    Serial.print("gb_init HATA: ");
    Serial.println(ret);
    char errBuf[32];
    snprintf(errBuf, sizeof(errBuf), "Emulator hata: %d", ret);
    showError(errBuf);
    romFile.close();
    delay(3000);
    drawMenu();
    return;
  }

  gb_init_lcd(&gb, lcd_draw_line_cb);

  char titleBuf[16];
  const char *title = gb_get_rom_name(&gb, titleBuf);
  Serial.print("Oyun Basligi: ");
  Serial.println(title);

  writeBufferIdx = 0;
  readBufferIdx = 1;
  core1Busy = false;
  memset(frameBuffer[0], 0, sizeof(frameBuffer[0]));
  memset(frameBuffer[1], 0, sizeof(frameBuffer[1]));

  memset(sharedPalette[0], 0, sizeof(sharedPalette[0]));
  memset(sharedPalette[1], 0, sizeof(sharedPalette[1]));

  tft.fillScreen(TFT_BLACK);
  tft.dmaWait(); 

  lastFpsTime = millis();
  frameCount = 0;
  currentFps = 0;

  emuRunning = true;
  tftOwnedByCore1 = true; 
  Serial.println("Emulasyon basliyor, ekran Core 1 kontrolunde!");
}

// ============================================================
// EMÜLATÖRÜ DURDUR (Watchdog Reboot Nedeniyle Sadece Fallback'tir)
// ============================================================
void stopEmulator() {
  emuRunning = false;

  while (core1Busy) { 
    delay(1);
  }

  tftOwnedByCore1 = false;
  tft.dmaWait();
  romFile.close();
  
  Serial.println("Emulasyon durduruldu, ekran kontrolü Core 0'a geri dondu.");
  drawMenu();
}

// ============================================================
// ROM TARAMA (/ROMS/ Klasörü) (GELİŞTİRİLDİ)
// ============================================================
void scanRoms() {
  tft.fillRect(0, 50, 320, 190, C_BG);
  tft.setTextColor(C_TEXT, C_BG);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("Oyunlar Taraniyor...", 160, 120, 2);

  romCount = 0;
  File32 dir;
  if (!dir.open("/ROMS/")) {
    showError("/ROMS/ klasoru bulunamadi!");
    return;
  }

  File32 file;
  char tempName[128]; 

  while (file.openNext(&dir, O_RDONLY)) {
    if (!file.isDir()) {
      memset(tempName, 0, sizeof(tempName));
      file.getName(tempName, sizeof(tempName));
      
      // Seri Porta Bulunan Dosyayı Yazdır (Sorun Çözümü ve Teşhis İçin)
      Serial.print("Bulunan Dosya: ");
      Serial.println(tempName);

      String filename = String(tempName);
      filename.toLowerCase();
      
      if (filename.endsWith(".gb") || filename.endsWith(".gbc")) {
        if (romCount < MAX_ROMS) {
          strncpy(romList[romCount], tempName, 63);
          romList[romCount][63] = '\0';
          romCount++;
        }
      }
    }
    file.close();
  }
  dir.close();

  if (romCount == 0) {
    showError("Hic oyun bulunamadi!");
  }
}

// ============================================================
// MENU ÇİZİMİ
// ============================================================
void drawMenu() {
  tft.fillScreen(C_BG);
  drawHeader("Oyun Secimi");

  int y = 50;
  for (int i = 0; i < VISIBLE_ITEMS; i++) {
    int listIndex = scrollOffset + i;
    if (listIndex >= romCount) break;
    bool isSelected = (listIndex == selectedIndex);

    if (isSelected) {
      tft.fillRoundRect(10, y, 300, 24, 4, C_ACCENT);
      tft.setTextColor(C_TITLE, C_ACCENT);
    } else {
      tft.fillRoundRect(10, y, 300, 24, 4, C_PANEL);
      tft.setTextColor(C_TEXT, C_PANEL);
    }

    tft.setTextDatum(ML_DATUM);
    tft.drawString(romList[listIndex], 20, y + 12, 2);
    y += 26;
  }

  tft.drawFastHLine(0, 225, 320, C_PANEL);
  tft.setTextColor(C_GRAY, C_BG);
  tft.setTextDatum(MC_DATUM);
  tft.drawString("A: Sec | YUKARI/ASAGI: Gezin", 160, 233, 1);
}

// ============================================================
// YARDIMCI FONKSIYONLAR
// ============================================================
void drawHeader(const char* title) {
  tft.fillRect(0, 0, 320, 35, C_PANEL);
  tft.drawFastHLine(0, 35, 320, C_ACCENT);
  tft.setTextColor(C_TITLE, C_PANEL);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(title, 160, 17, 2);
}

void showError(const char* errorMsg) {
  tft.fillScreen(C_BG);
  drawHeader("HATA");
  tft.setTextColor(0xF800, C_BG);
  tft.setTextDatum(MC_DATUM);
  tft.drawString(errorMsg, 160, 120, 2);
}